package com.abanoub.studyplanner

import android.app.*
import android.content.*
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private val Purple = Color(0xFF6C45E8)
private val PurpleDark = Color(0xFF4323A7)
private val Bg = Color(0xFFF9F7FF)

data class Task(val id: Long, val title: String, val day: Int, val hour: Int, val minute: Int, val duration: Int, val done: Boolean)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch("android.permission.POST_NOTIFICATIONS")
        setContent { StudyPlannerApp() }
    }
}

@Composable fun StudyPlannerApp() {
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }
    var tasks by remember { mutableStateOf(listOf(
        Task(1,"اللغة الألمانية", Calendar.SUNDAY,9,0,60,false),
        Task(2,"الرياضيات", Calendar.SUNDAY,11,0,60,true),
        Task(3,"الفيزياء", Calendar.SUNDAY,14,0,60,false)
    )) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(2200); splash = false }
    MaterialTheme(colorScheme = lightColorScheme(primary=Purple, background=Bg, surface=Color.White)) {
        AnimatedContent(splash, label="splash") { show -> if (show) Splash() else MainScreen(tab,tasks,{tab=it},{tasks=it}) }
    }
}

@Composable fun Splash() {
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment=Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.size(118.dp).clip(RoundedCornerShape(32.dp)).background(Purple), contentAlignment=Alignment.Center) {
                Icon(Icons.Default.EventNote,null,tint=Color.White,modifier=Modifier.size(62.dp))
            }
            Spacer(Modifier.height(20.dp)); Text("جدولي",fontSize=34.sp,fontWeight=FontWeight.Bold,color=PurpleDark)
            Spacer(Modifier.height(8.dp)); Text("نظّم وقتك • أنجز مهامك • حقق أهدافك",color=Color.Gray)
            Spacer(Modifier.height(34.dp)); Text("Developed by",fontSize=13.sp,color=Color.Gray)
            Spacer(Modifier.height(4.dp)); Text("Abanoub Samuel",fontSize=19.sp,fontWeight=FontWeight.SemiBold,color=Purple)
        }
    }
}

@Composable fun MainScreen(tab:Int,tasks:List<Task>,setTab:(Int)->Unit,setTasks:(List<Task>)->Unit) {
    var showAdd by remember { mutableStateOf(false) }
    Scaffold(containerColor=Bg, bottomBar={ NavigationBar(containerColor=Color.White) {
        NavItem("الرئيسية",Icons.Default.Home,tab==0){setTab(0)}
        NavItem("اليوم",Icons.Default.Checklist,tab==1){setTab(1)}
        Box(Modifier.padding(horizontal=10.dp).size(58.dp).clip(CircleShape).background(Purple).clickable{showAdd=true},contentAlignment=Alignment.Center){Icon(Icons.Default.Add,null,tint=Color.White)}
        NavItem("الجداول",Icons.Default.CalendarMonth,tab==2){setTab(2)}
        NavItem("التقارير",Icons.Default.BarChart,tab==3){setTab(3)}
    }}) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { when(tab){0->Dashboard(tasks,setTab);1->DayScreen(tasks,setTasks);2->WeeklyScreen();3->Reports(tasks)} } }
    if(showAdd) AddTaskDialog({showAdd=false}) { title,h,m,d -> setTasks(tasks + Task(System.currentTimeMillis(),title,Calendar.SUNDAY,h,m,d,false)); showAdd=false }
}

@Composable fun NavItem(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,selected:Boolean,onClick:()->Unit){ NavigationBarItem(selected=selected,onClick=onClick,icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)}) }

@Composable fun Dashboard(tasks:List<Task>,setTab:(Int)->Unit){ val done=tasks.count{it.done}; Column(Modifier.fillMaxSize().padding(18.dp)){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("مرحبًا 👋",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("جدولك اليومي بين يديك",color=Color.Gray)};Icon(Icons.Default.NotificationsNone,null,tint=Purple)}
    Spacer(Modifier.height(18.dp)); Card(colors=CardDefaults.cardColors(containerColor=Purple),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("إنجاز اليوم",color=Color.White.copy(.8f));Text("$done / ${tasks.size}",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Color.White);Text("استمر، أنت تستطيع! 🔥",color=Color.White)};Box(Modifier.size(82.dp).clip(CircleShape).background(Color.White.copy(.15f)),contentAlignment=Alignment.Center){Text("${if(tasks.isEmpty())0 else done*100/tasks.size}%",fontWeight=FontWeight.Bold,color=Color.White,fontSize=20.sp)}}}
    Spacer(Modifier.height(22.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("مهام اليوم",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("عرض الكل",color=Purple,modifier=Modifier.clickable{setTab(1)})}
    Spacer(Modifier.height(10.dp)); LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(tasks.take(5)){t->TaskCard(t,{})}}
}}

@Composable fun TaskCard(t:Task,onToggle:()->Unit){Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(if(t.done)Color(0xFFE4F7EC) else Color(0xFFF0ECFF)),contentAlignment=Alignment.Center){Icon(if(t.done)Icons.Default.Check else Icons.Default.MenuBook,null,tint=if(t.done)Color(0xFF1FA463) else Purple)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(t.title,fontWeight=FontWeight.Bold);Text(String.format("%02d:%02d • %d دقيقة",t.hour,t.minute,t.duration),fontSize=12.sp,color=Color.Gray)};Checkbox(t.done,onCheckedChange={onToggle()})}}}

@Composable fun DayScreen(tasks:List<Task>,setTasks:(List<Task>)->Unit){ Column(Modifier.fillMaxSize().padding(18.dp)){Text("مهام اليوم",fontSize=27.sp,fontWeight=FontWeight.Bold);Text(SimpleDateFormat("EEEE، d MMMM",Locale("ar")).format(Date()),color=Color.Gray);Spacer(Modifier.height(18.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(tasks){t->TaskCard(t){setTasks(tasks.map{if(it.id==t.id)it.copy(done=!it.done)else it})}}}} }

@Composable fun WeeklyScreen(){ Column(Modifier.fillMaxSize().padding(18.dp)){Text("الجداول الأسبوعية",fontSize=27.sp,fontWeight=FontWeight.Bold);Text("كل جدول مستقل عن الآخر",color=Color.Gray);Spacer(Modifier.height(18.dp));listOf("جدول الأسبوع الحالي","جدول الامتحانات","خطة المراجعة المكثفة").forEachIndexed{idx,name->Card(shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth().padding(bottom=12.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(listOf(Color(0xFFEDE7FF),Color(0xFFE3F2FD),Color(0xFFE8F5E9))[idx]),contentAlignment=Alignment.Center){Icon(Icons.Default.CalendarMonth,null,tint=Purple)};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold);Text("الأحد → السبت",fontSize=12.sp,color=Color.Gray)};Icon(Icons.Default.ChevronLeft,null)}};Spacer(Modifier.height(4.dp));Button(onClick={},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("إنشاء جدول أسبوعي جديد")}} }

@Composable fun Reports(tasks:List<Task>){val done=tasks.count{it.done};Column(Modifier.fillMaxSize().padding(18.dp)){Text("التقارير",fontSize=27.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(18.dp));Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp)){Text("نسبة الإنجاز",color=Color.Gray);Text("${if(tasks.isEmpty())0 else done*100/tasks.size}%",fontSize=42.sp,fontWeight=FontWeight.Bold,color=Purple);LinearProgressIndicator(progress={if(tasks.isEmpty())0f else done.toFloat()/tasks.size},modifier=Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(10.dp)))}};Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("إجمالي المهام",tasks.size.toString());Stat("مكتملة",done.toString());Stat("متبقية",(tasks.size-done).toString())}}}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(15.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(b,fontSize=25.sp,fontWeight=FontWeight.Bold,color=Purple);Text(a,fontSize=12.sp,color=Color.Gray)}}}

@Composable fun AddTaskDialog(onDismiss:()->Unit,onSave:(String,Int,Int,Int)->Unit){var title by remember{mutableStateOf("")};var hour by remember{mutableStateOf(17)};var min by remember{mutableStateOf(0)};var dur by remember{mutableStateOf(60)};AlertDialog(onDismissRequest=onDismiss,title={Text("إضافة مهمة جديدة")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(title,{title=it},label={Text("اسم المهمة")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(hour.toString(),{hour=it.filter(Char::isDigit).toIntOrNull()?.coerceIn(0,23)?:0},label={Text("الساعة")},modifier=Modifier.weight(1f));OutlinedTextField(min.toString().padStart(2,'0'),{min=it.filter(Char::isDigit).toIntOrNull()?.coerceIn(0,59)?:0},label={Text("الدقيقة")},modifier=Modifier.weight(1f))};OutlinedTextField(dur.toString(),{dur=it.filter(Char::isDigit).toIntOrNull()?:60},label={Text("المدة بالدقائق")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank(),onClick={onSave(title,hour,min,dur)}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})}
